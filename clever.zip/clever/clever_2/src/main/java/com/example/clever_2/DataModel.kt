package com.example.clever_2

data class DataModel(val title: String?, val description: String?)
